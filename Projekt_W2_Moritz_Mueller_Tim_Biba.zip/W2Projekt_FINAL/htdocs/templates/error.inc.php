<div class="container">
<h2>Fehler</h2>

<?php echo $error_msg; ?>
</div>